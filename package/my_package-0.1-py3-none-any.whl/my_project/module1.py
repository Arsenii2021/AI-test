# Файл, содержащий код вашего пакета.

# Пример определения функции:
def some_function1():
    print("This is some_function1 from module1")

