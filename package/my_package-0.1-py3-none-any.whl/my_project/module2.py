# Файл, содержащий код вашего пакета.

# Пример определения функции:
def some_function2():
    print("This is some_function2 from module2")

